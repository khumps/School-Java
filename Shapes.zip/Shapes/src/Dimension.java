/*A Dimension contains a  width and a height*/
public class Dimension {
	protected int height;
	protected int width;

	/* Creates a new Dimension with the given width and height */
	public Dimension(int width, int height) {
		this.width = width;
		this.height = height;
	}

}
